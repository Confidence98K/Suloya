/* ============================================================
   CONFIDENCE MOHLomi — SHARED FOOTER
   Injected on every page so the footer only needs to be
   maintained in one place. Pure client-side string injection
   (no fetch), so it works when the site is opened directly
   from disk as well as from a local/live server.
   ============================================================ */

(function () {
  var mount = document.getElementById("site-footer-include");
  if (!mount) return;

  mount.innerHTML = [
    '<div class="container">',
    '  <div class="footer-grid">',
    '    <div class="footer-brand">',
    '      <a href="index.html" class="brand">',
    '        <img src="assets/logo.png" alt="Suloyal International logo" style="height:38px;width:38px;">',
    '        <span class="brand-name">SU<span>LOYAL</span></span>',
    '      </a>',
    '      <p>Where global reach meets local expertise. International sourcing, trade and supply-chain solutions since 2011.</p>',
    '      <div class="footer-social" style="margin-top:22px;">',
    '        <a href="#" aria-label="Suloyal on LinkedIn"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M4.98 3.5a2.5 2.5 0 11-.02 5 2.5 2.5 0 01.02-5zM3 9h4v12H3zM9 9h3.8v1.7h.05c.53-1 1.83-2.05 3.77-2.05C20.6 8.65 21 11 21 14.15V21h-4v-6.1c0-1.46-.03-3.35-2.05-3.35-2.06 0-2.37 1.6-2.37 3.25V21H9z"/></svg></a>',
    '        <a href="#" aria-label="Suloyal on WhatsApp"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.28-1.38a9.9 9.9 0 004.76 1.21h.01c5.46 0 9.9-4.45 9.9-9.91C21.96 6.45 17.5 2 12.04 2zm0 18.13a8.2 8.2 0 01-4.19-1.15l-.3-.18-3.13.82.84-3.05-.2-.31a8.18 8.18 0 01-1.26-4.35c0-4.53 3.69-8.22 8.24-8.22 4.55 0 8.24 3.69 8.24 8.22 0 4.53-3.69 8.22-8.24 8.22z"/></svg></a>',
    '        <a href="#" aria-label="Suloyal on TikTok"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M16.5 2h-3v13.5a3 3 0 11-2.5-2.96V9.4a6 6 0 106.5 6V8.9a7.6 7.6 0 004 1.1V7A4.5 4.5 0 0116.5 2z"/></svg></a>',
    '      </div>',
    '    </div>',
    '    <div class="footer-col">',
    '      <h5>Company</h5>',
    '      <ul>',
    '        <li><a href="about.html">About Us</a></li>',
    '        <li><a href="solutions.html">Solutions</a></li>',
    '        <li><a href="products.html">Products</a></li>',
    '        <li><a href="why-suloyal.html">Why Suloyal</a></li>',
    '        <li><a href="global-reach.html">Global Reach</a></li>',
    '        <li><a href="contact.html">Contact</a></li>',
    '      </ul>',
    '    </div>',
    '    <div class="footer-col">',
    '      <h5>Offices</h5>',
    '      <address>Guangzhou Import &amp; Export<br>R830, 8th Floor, Garden Building<br>369 Huangshidong Rd, Yuexiu District<br>Guangzhou, China</address>',
    '      <address>Allcomt Technology B.V.<br>Barbara Strozzilaan 201<br>1083 HN Amsterdam<br>The Netherlands</address>',
    '    </div>',
    '    <div class="footer-col">',
    '      <h5>Direct Contact</h5>',
    '      <ul>',
    '        <li>Sully / Sherry Xie — Director</li>',
    '        <li><a href="https://wa.me/8613430370872">WhatsApp: +86 134 3037 0872</a></li>',
    '        <li>WeChat: +86 134 3037 0872</li>',
    '        <li><a href="mailto:admin@suloya.co.za">admin@suloya.co.za</a></li>',

    '      </ul>',
    '    </div>',
    '  </div>',
    '  <div class="footer-bottom">',
    '    <span>&copy; <span id="year"></span> Confidence Mohlomi. All rights reserved.</span>',
    '    <span>Connect. Simplify. Deliver. Grow.</span>',
    '  </div>',
    '</div>'
  ].join("\n");

  var yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();
})();
